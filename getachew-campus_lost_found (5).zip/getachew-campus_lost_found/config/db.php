<?php
$host = 'localhost';
$user = 'root';
$pass = ''; // እንደ MariaDB setup ህ ፓስወርድ ካለህ እዚህ አስገባ
$dbname = 'campus_lost_found';

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Database Connection Failed: " . $conn->connect_error);
}
?>