<?php
require_once 'config/db.php';
include 'includes/header.php';

$query = "SELECT items.*, users.username FROM items JOIN users ON items.user_id = users.id ORDER BY date_reported DESC";
$result = $conn->query($query);
?>

<h2 style="margin-bottom: 0.5rem;">Browse Lost & Found Items</h2>
<p style="color: var(--text-muted); margin-bottom: 1.5rem;">All items reported by students and staff members on campus.</p>

<div class="grid">
    <?php if ($result && $result->num_rows > 0): ?>
        <?php while ($row = $result->fetch_assoc()): ?>
            <div class="card <?php echo htmlspecialchars($row['category']); ?>">
                <div>
                    <span class="badge badge-<?php echo strtolower($row['category']); ?>">
                        <?php echo htmlspecialchars($row['category']); ?>
                    </span>
                    <h3><?php echo htmlspecialchars($row['title']); ?></h3>
                    <p class="card-info"><strong>Description:</strong> <?php echo htmlspecialchars($row['description']); ?></p>
                    <p class="card-info"><strong>Location:</strong> <?php echo htmlspecialchars($row['location']); ?></p>
                    <p class="card-info"><strong>Phone:</strong> <?php echo htmlspecialchars($row['contact_phone']); ?></p>
                </div>
                <div class="card-footer">
                    Posted by <strong><?php echo htmlspecialchars($row['username']); ?></strong> on <?php echo date('M d, Y', strtotime($row['date_reported'])); ?>
                </div>
            </div>
        <?php endwhile; ?>
    <?php else: ?>
        <p>No items reported yet.</p>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>