<?php
require_once 'config/db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $sender_name = trim($_POST['sender_name']);
    $email = trim($_POST['email']);
    $message = trim($_POST['message']);

    // Input Validation
    if (empty($sender_name) || empty($email) || empty($message)) {
        $error = "Please fill in all required fields.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Please enter a valid email address.";
    } else {
        // Prepared Statement በመጠቀም መልእክቱን ወደ Database ማስገባት
        $stmt = $conn->prepare("INSERT INTO messages (sender_name, email, message) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $sender_name, $email, $message);

        if ($stmt->execute()) {
            $success = "Thank you! Your message has been sent successfully. We will get back to you soon.";
        } else {
            $error = "Failed to send your message. Please try again later.";
        }
        $stmt->close();
    }
}

include 'includes/header.php';
?>

<div style="max-width: 900px; margin: 0 auto;">
    
    <!-- Page Title & Subtitle -->
    <div style="text-align: center; margin-bottom: 2rem;">
        <h2 style="font-size: 2.2rem; color: var(--secondary-color); margin-bottom: 0.5rem;">Contact Us</h2>
        <p style="color: var(--text-muted);">Have questions, feedback, or need help? Send us a message below.</p>
    </div>

    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 2rem; align-items: start;">
        
        <!-- Contact Information Card -->
        <div class="card" style="padding: 2rem;">
            <h3 style="color: var(--primary-color); margin-bottom: 1.2rem; font-size: 1.4rem;">Get in Touch</h3>
            
            <div style="margin-bottom: 1.2rem;">
                <strong style="display: block; color: var(--text-dark);">Office Location:</strong>
                <span style="color: var(--text-muted); font-size: 0.95rem;">Student Service Building, Room 102</span>
            </div>

            <div style="margin-bottom: 1.2rem;">
                <strong style="display: block; color: var(--text-dark);">Email Address:</strong>
                <span style="color: var(--text-muted); font-size: 0.95rem;">support@campuslostfound.edu.et</span>
            </div>

            <div style="margin-bottom: 1.2rem;">
                <strong style="display: block; color: var(--text-dark);">Phone Number:</strong>
                <span style="color: var(--text-muted); font-size: 0.95rem;">+251 911 000 000 / +251 111 223 344</span>
            </div>

            <div>
                <strong style="display: block; color: var(--text-dark);">Working Hours:</strong>
                <span style="color: var(--text-muted); font-size: 0.95rem;">Monday - Friday: 8:30 AM - 5:00 PM</span>
            </div>
        </div>

        <!-- Contact Form Card -->
        <div class="form-card" style="margin: 0; width: 100%; max-width: 100%;">
            <h3 style="margin-bottom: 1.2rem; color: var(--secondary-color); font-size: 1.4rem; text-align: center;">Send a Message</h3>

            <?php if ($error): ?>
                <div class="alert alert-error"><?php echo $error; ?></div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>

            <form action="contact.php" method="POST">
                <div class="form-group">
                    <label for="sender_name">Your Name</label>
                    <input type="text" id="sender_name" name="sender_name" placeholder="Enter your full name" required>
                </div>

                <div class="form-group">
                    <label for="email">Your Email</label>
                    <input type="email" id="email" name="email" placeholder="Enter your email address" required>
                </div>

                <div class="form-group">
                    <label for="message">Message</label>
                    <textarea id="message" name="message" rows="5" placeholder="Write your message or inquiry here..." required></textarea>
                </div>

                <button type="submit" class="btn btn-primary" style="width: 100%;">Send Message</button>
            </form>
        </div>

    </div>
</div>

<?php include 'includes/footer.php'; ?>