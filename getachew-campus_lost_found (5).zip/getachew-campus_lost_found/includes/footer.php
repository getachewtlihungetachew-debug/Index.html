</main>
    <footer>
        <p>&copy; <?php echo date('Y'); ?> Campus Lost & Found Portal. All rights reserved.</p>
    </footer>
    <script src="js/main.js"></script>
</body>
</html>