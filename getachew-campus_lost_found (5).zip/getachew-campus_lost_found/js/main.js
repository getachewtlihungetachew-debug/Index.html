document.addEventListener('DOMContentLoaded', () => {
    const forms = document.querySelectorAll('form');

    forms.forEach(form => {
        form.addEventListener('submit', (e) => {
            const inputs = form.querySelectorAll('input[required], textarea[required]');
            let valid = true;

            inputs.forEach(input => {
                if (!input.value.trim()) {
                    valid = false;
                    input.style.borderColor = '#ef4444';
                } else {
                    input.style.borderColor = '#ccc';
                }
            });

            if (!valid) {
                e.preventDefault();
                alert('እባክዎን ሁሉንም አስፈላጊ መስኮች በትክክል ይሙሉ!');
            }
        });
    });
});