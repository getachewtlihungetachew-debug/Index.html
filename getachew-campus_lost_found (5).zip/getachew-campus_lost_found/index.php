<?php include 'includes/header.php'; ?>

<div class="hero">
    <h1>Lost Something on Campus?</h1>
    <p>Report missing items or browse returned belongings to connect with owners quickly and safely.</p>
    <div class="hero-btns">
        <a href="items.php" class="btn btn-primary">Browse All Items</a>
        <a href="report_item.php" class="btn btn-secondary">Report an Item</a>
    </div>
</div>

<h2 style="text-align: center; margin-bottom: 0.5rem; font-size: 2rem; color: var(--secondary-color);">How It Works</h2>
<p style="text-align: center; color: var(--text-muted); margin-bottom: 2rem;">A simple 3-step process to return or find items on campus.</p>

<div class="features-grid">
    <div class="feature-box">
        <h3>1. Create Account</h3>
        <p>Register with your student details to start posting and recovering lost items securely.</p>
    </div>
    <div class="feature-box">
        <h3>2. Post or Search</h3>
        <p>List an item you found on campus or search through reported missing belongings.</p>
    </div>
    <div class="feature-box">
        <h3>3. Connect Safely</h3>
        <p>Use provided contact numbers to verify ownership and arrange a safe exchange.</p>
    </div>
</div>

<?php include 'includes/footer.php'; ?>