<?php include 'includes/header.php'; ?>

<div style="max-width: 800px; margin: 0 auto;">
    <div class="card" style="margin-bottom: 2rem;">
        <h2 style="color: var(--primary-color); margin-bottom: 1rem;">Student & Course Information</h2>
        <p class="card-info"><strong>Full Name:</strong> Getachew tlahun</p>
        <p class="card-info"><strong>Student ID:</strong> 057/16</p>
        <p class="card-info"><strong>Department:</strong> Department of Computer Science</p>
        <p class="card-info"><strong>Course:</strong> Web Programming (CoSc3091)</p>
        <p class="card-info"><strong>Project Title:</strong> Campus Lost and Found Portal</p>
        
        <h3 style="margin-top: 1.5rem; margin-bottom: 0.5rem;">Personal Background</h3>
        <p>
            I am a Computer Science student with a strong passion for full-stack web development. 
            Through this course project, I developed practical skills in semantic HTML5 markup, responsive CSS layout, 
            client-side JavaScript validation, and secure PHP server logic with MariaDB integration.
        </p>
    </div>

    <div class="card">
        <h2 style="color: var(--primary-color); margin-bottom: 1rem;">About the System</h2>
        <p>
            The <strong>Campus Lost & Found Portal</strong> is designed to solve the common issue of misplaced items 
            within university grounds. It provides a centralized, easy-to-use digital bulletin board where students 
            and staff can post details of items lost or found, facilitating quick recovery through direct communication.
        </p>
    </div>
</div>

<?php include 'includes/footer.php'; ?>