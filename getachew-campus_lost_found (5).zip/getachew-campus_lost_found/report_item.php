<?php
require_once 'config/db.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title']);
    $category = $_POST['category'];
    $description = trim($_POST['description']);
    $location = trim($_POST['location']);
    $contact_phone = trim($_POST['contact_phone']);
    $user_id = $_SESSION['user_id'];

    if (empty($title) || empty($category) || empty($description) || empty($location) || empty($contact_phone)) {
        $error = "Please fill in all required fields.";
    } else {
        $stmt = $conn->prepare("INSERT INTO items (user_id, title, category, description, location, contact_phone) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("isssss", $user_id, $title, $category, $description, $location, $contact_phone);

        if ($stmt->execute()) {
            $success = "Item reported successfully! <a href='items.php'>View All Items</a>";
        } else {
            $error = "Failed to report the item.";
        }
        $stmt->close();
    }
}
include 'includes/header.php';
?>

<div class="form-card">
    <h2>Report Lost or Found Item</h2>
    
    <?php if ($error): ?><div class="alert alert-error"><?php echo $error; ?></div><?php endif; ?>
    <?php if ($success): ?><div class="alert alert-success"><?php echo $success; ?></div><?php endif; ?>

    <form action="report_item.php" method="POST">
        <div class="form-group">
            <label>Item Title</label>
            <input type="text" name="title" placeholder="e.g. Blue HP Backpack" required>
        </div>
        <div class="form-group">
            <label>Category</label>
            <select name="category" required>
                <option value="Lost">Lost</option>
                <option value="Found">Found</option>
            </select>
        </div>
        <div class="form-group">
            <label>Location</label>
            <input type="text" name="location" placeholder="e.g. Library 2nd Floor" required>
        </div>
        <div class="form-group">
            <label>Contact Phone Number</label>
            <input type="text" name="contact_phone" placeholder="e.g. 0911223344" required>
        </div>
        <div class="form-group">
            <label>Item Description</label>
            <textarea name="description" rows="4" placeholder="Provide extra details (color, brand, distinctive marks)..." required></textarea>
        </div>
        <button type="submit" class="btn btn-primary" style="width: 100%;">Submit Report</button>
    </form>
</div>

<?php include 'includes/footer.php'; ?>