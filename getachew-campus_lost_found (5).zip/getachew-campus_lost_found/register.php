<?php
require_once 'config/db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ተጠቃሚው ገና Login ካደረገ በድጋሚ የመመዝገቢያ ገጽ እንዳይከፈት ወደ Home መመለስ
if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    // Basic Input Validation
    if (empty($full_name) || empty($email) || empty($username) || empty($password)) {
        $error = "Please fill in all required fields.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Please enter a valid email address.";
    } else {
        // Username ወይም Email ቀደም ብሎ መኖሩን በPrepared Statement ማረጋገጥ
        $stmt = $conn->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
        $stmt->bind_param("ss", $username, $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $error = "Username or Email address is already registered.";
        } else {
            // Password Hashing (መመሪያው በሚጠይቀው መሰረት)
            $hashed_password = password_hash($password, PASSWORD_BCRYPT);

            $insert_stmt = $conn->prepare("INSERT INTO users (full_name, email, username, password) VALUES (?, ?, ?, ?)");
            $insert_stmt->bind_param("ssss", $full_name, $email, $username, $hashed_password);

            if ($insert_stmt->execute()) {
                $success = "Registration successful! You can now <a href='login.php' style='color: #166534; font-weight: bold;'>Login here</a>.";
            } else {
                $error = "Something went wrong during registration. Please try again.";
            }
            $insert_stmt->close();
        }
        $stmt->close();
    }
}

include 'includes/header.php';
?>

<div class="form-card">
    <h2>Create an Account</h2>

    <?php if ($error): ?>
        <div class="alert alert-error"><?php echo $error; ?></div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="alert alert-success"><?php echo $success; ?></div>
    <?php endif; ?>

    <form action="register.php" method="POST">
        <div class="form-group">
            <label for="full_name">Full Name</label>
            <input type="text" id="full_name" name="full_name" placeholder="e.g. Abebe Bikila" required>
        </div>

        <div class="form-group">
            <label for="email">Email Address</label>
            <input type="email" id="email" name="email" placeholder="e.g. abebe@gmail.com" required>
        </div>

        <div class="form-group">
            <label for="username">Username</label>
            <input type="text" id="username" name="username" placeholder="Choose a unique username" required>
        </div>

        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" id="password" name="password" placeholder="Create a strong password" required>
        </div>

        <button type="submit" class="btn btn-primary" style="width: 100%;">Register</button>
    </form>

    <p style="text-align: center; margin-top: 1.5rem; font-size: 0.9rem; color: var(--text-muted);">
        Already have an account? <a href="login.php" style="color: var(--primary-color); font-weight: 600;">Login here</a>
    </p>
</div>

<?php include 'includes/footer.php'; ?>