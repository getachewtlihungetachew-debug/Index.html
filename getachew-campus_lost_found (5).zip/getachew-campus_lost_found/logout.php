<?php
// Session ማስጀመር
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ሁሉንም Session መረጃዎች ማጽዳት
$_SESSION = array();

// Session Cookie ካለ ማጥፋት
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// Session ሙሉ በሙሉ ማጥፋት
session_destroy();

// ተጠቃሚውን ቀጥታ ወደ Login ገጽ መመለስ
header("Location: login.php");
exit();
?>